<?php

    $sever="localhost";
    $user="root";
    $pass="";
    $db="bank";

    $conn=mysqli_connect($sever,$user,$pass,$db);
   if ($conn) {
       //echo "connection successful";
   }
   else{
    echo "connection failed.".mysqli_connect_error();
   }
?>
