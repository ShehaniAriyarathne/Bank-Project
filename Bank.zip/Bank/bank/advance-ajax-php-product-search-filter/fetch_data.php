<?php

//fetch_data.php

include('database_connection.php');

if(isset($_POST["action"]))
{
	$query = "
		SELECT * FROM new_job WHERE job_status = '1'
	";
	
	if(isset($_POST["title"]))
	{
		$title_filter = implode("','", $_POST["title"]);
		$query .= "
		 AND job_title IN('".$title_filter."')
		";
	}
	if(isset($_POST["location"]))
	{
		$location_filter = implode("','", $_POST["location"]);
		$query .= "
		 AND job_location IN('".$location_filter."')
		";
	}
	

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$total_row = $statement->rowCount();
	$output = '';
	if($total_row > 0)
	{
		foreach($result as $row)
		{
			$output .= '
			<div class="col-sm-4 col-lg-3 col-md-3">
				<div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
					<img src="image/'. $row['photo'] .'" alt="" class="img-responsive" >
					<p align="center"><strong><a href="#">'. $row['job_title'] .'</a></strong></p>
					<h4 style="text-align:center;" class="text-danger" >'. $row['job_location'] .'</h4>
					<p>Closing date : '. $row['closing_date'].'<br />
					Contract type : '. $row['contract_type'] .' <br />
					
					 </p>
				</div>

			</div>
			';
		}
	}
	else
	{
		$output = '<h3>No Data Found</h3>';
	}
	echo $output;
}

?>