<?php
include 'functions/dbconnection.php';

if(isset($_GET['action']) && $_GET['action']=="delete")
{
  $de="delete from `bank_branch` where 	branch_id='$_GET[id]'";
$deq=mysqli_query($conn,$de);
}


?>




<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

 
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>



<h6 class="mb-0 text-uppercase">Branch Details</h6>
				<hr/>
				<div class="card">
					<div class="card-body">
					<div class="border p-1 rounded">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>Branch Id</th>
										<th>Branch Name</th>
										<th>Address</th>
                                        <th>Action</th>
										 
									</tr>
								</thead>
								<tbody>
								<?php
                                $list='select * from `bank_branch`';
                                $listq=mysqli_query($conn,$list);
                                while($listqf=mysqli_fetch_array($listq)){
								?>
									<tr>
										<td><?php echo $listqf['branch_id'];?></td>
										<td><?php echo $listqf['branch_name'];?></td>
                                        <td><?php  echo $listqf['branch_address'];?></td>
										 <?php $lid= $listqf['branch_id'];?>
                    <td>
                   <a  href="edit.php?id=<?php echo $lid;?>" class="btn btn-primary btn-sm"><i class="fas fa-pencil-alt"> Edit </i></a> 
                   <button type="button" class="btn btn-danger btn-sm" onclick="return confirm('Are you Sure Delete ?')"><a href="?id=<?php echo $listqf['branch_id'];?>&action=delete" style="color: #ffffff !important; text-decoration: none !important;"><i class="fa fa-trash">Delete</i></a></button>      
                  </td>
										
									</tr>
									<?php } ?>
								</tbody>
								
							</table>
						</div>
					</div>
					</div>
				</div>

				
</div>
					</div>
				</div>
							<br> <br> <br> <br>
				
</body>
<script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</html>