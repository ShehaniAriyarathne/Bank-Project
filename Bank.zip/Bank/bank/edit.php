<?php
include 'functions/dbconnection.php';
?>

<?php

$id = $_GET['id'];
echo $id;
$list="select * from `bank_branch` where branch_id='$id'";
$listq=mysqli_query($conn,$list);
$listqf=mysqli_fetch_assoc($listq);

?>

<?php 
if(isset($_POST['Edit']))
{
$ins="update `bank_branch` set `branch_name`='$_POST[name]',`branch_address`='$_POST[address]' where id=$id";
$insq=mysqli_query($conn,$ins);

?>

<script>

  window.location ="add-branch.php";
 
</script>

<?php }?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Branch</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

 
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Edit Branch</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
								<div class="border p-1 rounded">
									<form action="" method="post">
										<div class="mb-3">
										<label class="form-label">Bank Name</label>
										<input class="form-control mb-3" name="name" type="text" aria-label="default input example" value="<?php echo $listqf['branch_name'];?>">
									</div>
									<div class="mb-3">
										<label class="form-label">Address</label>
										<input class="form-control mb-3" name="address"type="text"  aria-label="default input example" value="<?php echo $listqf['branch_address'];?>">
									</div>
									 <div class="row">
										
										<div class="col-sm-18">
                                        <input type="submit" name="Edit" value="Edit" class="btn btn-info px-5"></button>
										</div>
									</div>
									</form>
									</div>
									</div>

               
</body>
<script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</html>