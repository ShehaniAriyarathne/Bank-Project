<?php 
error_reporting(0);
$uname=($_POST["uname"]);
$password=($_POST["password"]);
$error="";
$success="";

if(isset($_POST["login"])){
  if ($uname=="admin") {
    if ($password=="password") {
      $error="";
      //$success="welcome";
      header("location:admin_panel.php");
    }
    else{
      $error="Invalid password";
      $success="";
    }

  }
  else{
      $error="Invalid Username";
      $success="";
  }
}
 ?>


 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin Login</title>
    <!-- jQuery + Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
   

   * {
  box-sizing: border-box;
}

body {
  font-weight: 400;
  background-color: white;
}

body,
html,
.App,
.vertical-center {
  width: 100%;
  height: 100%;
}

.navbar {
  background: #1833FF !important;
  width: 100%;
}

.btn-outline-primary {
  border-color: black;
  color: black;
}

.btn-outline-primary:hover {
  background-color: black;
  color: white;
}

.vertical-center {
  display: flex;
  text-align: left;
  justify-content: center;
  flex-direction: column;
}

.inner-block {
  width: 450px;
  margin: auto;
  background: #ffffff;
  box-shadow: 0px 14px 80px rgba(34, 35, 58, 0.2);
  padding: 40px 55px 45px 55px;
  transition: all .3s;
  border-radius: 20px;
}

.vertical-center .form-control:focus {
  border-color: #2554FF;
  box-shadow: none;
}

.vertical-center h3 {
  text-align: center;
  margin: 0;
  line-height: 1;
  padding-bottom: 20px;
}

label {
  font-weight: 500;
}
</style>
<body>

    <!-- Login form -->
    <div class="App">
        <div class="vertical-center">
            <div class="inner-block">
              <p class="error"><?php echo $error;?></p>
              <p class="success"><?php echo $success;?></p>
                <form action="#" method="POST">
                    <h3>ADMIN LOGIN</h3>
                    <div class="form-group">
                        
                        <input type="text" class="form-control" name="uname" placeholder="USER NAME" id="" required />
                    </div>

                    <div class="form-group">
                        
                        <input type="password" class="form-control" name="password" placeholder="PASSWORD" id=""  required />
                    </div>

                    <button type="submit" name="login" id="" style="background-color: black;color: white;" 
                        class="btn btn-outline-primary btn-lg btn-block">LOGIN</button>
                </form>
            </div>
        </div>
    </div>

</body>

</html>