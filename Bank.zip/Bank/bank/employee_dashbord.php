<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0"/>

  <title>ABC BANK</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

 
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<style>
  

body {
  background:  white;
  color: #000000;
  font-family: "Open Sans", sans-serif;
}

a {
  color: #1bb1dc;
  transition: 0.5s;
}

a:hover, a:active, a:focus {
  color: #0a98c0;
  outline: none;
  text-decoration: none;
}

p {
  padding: 0;
  margin: 0 0 30px 0;
}

h1, h2, h3, h4, h5, h6 {
  font-family: "Montserrat", sans-serif;
  /*font-weight: 400;*/
  margin: 0 0 20px 0;
  padding: 0;
}

/* Back to top button */
.back-to-top {
  position: fixed;
  display: none;
  background: #1bb1dc;
  color: #fff;
  width: 44px;
  height: 44px;
  text-align: center;
  line-height: 1;
  font-size: 16px;
  border-radius: 50%;
  right: 15px;
  bottom: 15px;
  transition: background 0.5s;
  z-index: 11;
}

.back-to-top i {
  padding-top: 12px;
  color: #fff;
}

@media (max-width: 768px) {
  .back-to-top {
    bottom: 15px;
  }
}

/* Prelaoder */
#preloader {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  overflow: hidden;
  background: #fff;
}

#preloader:before {
  content: "";
  position: fixed;
  top: calc(50% - 30px);
  left: calc(50% - 30px);
  border: 6px solid #f2f2f2;
  border-top: 6px solid #1bb1dc;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  -webkit-animation: animate-preloader 1s linear infinite;
  animation: animate-preloader 1s linear infinite;
}

@-webkit-keyframes animate-preloader {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes animate-preloader {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/*--------------------------------------------------------------
# Disable aos animation delay on mobile devices
--------------------------------------------------------------*/
@media screen and (max-width: 768px) {
  [data-aos-delay] {
    transition-delay: 0 !important;
  }
}

/*--------------------------------------------------------------
# Top Bar
--------------------------------------------------------------*/
#topbar {
  background: #fff;
  height: 40px;
  font-size: 16px;
  transition: all 0.5s;
  padding-right: 40px;
}



#topbar.topbar-scrolled {
  top: -40px;
}

#topbar .social-links a {
  color: #413e66;
  padding-left: 20px;
  display: inline-block;
  line-height: 1px;
  transition: 0.3s;
}

#topbar .social-links a:hover {
  color: #1bb1dc;
}

#topbar .social-links a:first-child {
  border-left: 0;
}



/*--------------------------------------------------------------
# Header
--------------------------------------------------------------*/
#header {
  background: white;
  transition: all 0.5s;
  z-index: 997;
  padding: 15px 0;
  top: 40px;
  
}

#header.header-transparent {
  background: white;
}

#header.header-scrolled {
  top: 0;
  background: #fff;
  box-shadow: 0px 0px 30px rgba(127, 137, 161, 0.3);
}

#header .logo {
  font-size: 20px;
  margin: 0;
  padding: 0;
  line-height: 1;
  font-weight: 800;
  letter-spacing: 3px;
  }

#header .logo a {
  font-weight: 300;
  color: blue;
}

#header .logo img {
  max-height: 40px;
  font-weight: 300;
}

@media (max-width: 992px) {
  #header {
    top: 0;
  }
  #header .logo {
    font-size: 30px;
    font-weight: 300;
  }
}


/*--------------------------------------------------------------
# Navigation Menu
--------------------------------------------------------------*/
/* Desktop Navigation */
.main-nav {
  /* Drop Down */
  /* Deep Drop Down */

}

.main-nav, .main-nav * {
  margin: 0;
  padding: 0;
  list-style: none;
  
}

.main-nav > ul > li {
  position: relative;
  white-space: nowrap;
  float: left;
  padding-left: 20px;
  padding-right: 20px;
  
}

.main-nav a {
  display: block;
  position: relative;
  color: black;
  padding: 10px 0;
  transition: 0.3s;
  font-size: 17px;
  font-family: "Open Sans", sans-serif;
  text-align: center;
  font-weight: 600;

}


.main-nav :hover{
  color:white;
  background-color: black;
}


/* Mobile Navigation */
.mobile-nav {
  position: fixed;
  top: 0;
  bottom: 0;
  z-index: 9999;
  overflow-y: auto;
  left: -260px;
  width: 260px;
 
  background: rgba(40, 38, 70, 0.8);
  transition: 0.4s;
}

.mobile-nav * {
  margin: 0;
  padding: 0;
  list-style: none;
}

.mobile-nav a {
  display: block;
  position: relative;
  color: #fff;
  padding: 10px 20px;
  font-weight: 500;
}

.mobile-nav a:hover, .mobile-nav .active > a, .mobile-nav li:hover > a {
  color: #8dc2fa;
  text-decoration: none;
}

.mobile-nav .drop-down > a:after {
  content: "\f078";
  font-family: FontAwesome;
  padding-left: 10px;
  position: absolute;
  right: 15px;
}

.mobile-nav .active.drop-down > a:after {
  content: "\f077";
}

.mobile-nav .drop-down > a {
  padding-right: 35px;
}

.mobile-nav .drop-down ul {
  display: none;
  overflow: hidden;
}

.mobile-nav .drop-down li {
  padding-left: 20px;
}

.mobile-nav-toggle {
  position: fixed;
  right: 0;
  top: 0;
  z-index: 9998;
  border: 0;
  background: none;
  font-size: 24px;
  transition: all 0.4s;
  outline: none !important;
  line-height: 1;
  cursor: pointer;
  text-align: right;
}

.mobile-nav-toggle i {
  margin: 18px 18px 0 0;
  color: #065e77;
}

.mobile-nav-overly {
  width: 100%;
  height: 100%;
  z-index: 9997;
  top: 0;
  left: 0;
  position: fixed;
  background: rgba(40, 38, 70, 0.8);
  overflow: hidden;
  display: none;
}

.mobile-nav-active {
  overflow: hidden;
}

.mobile-nav-active .mobile-nav {
  left: 0;
}

.mobile-nav-active .mobile-nav-toggle i {
  color: #fff;
}


/*--------------------------------------------------------------
# Sections
--------------------------------------------------------------*/
section {
  overflow: hidden;
}

/* Sections Header
--------------------------------*/
.section-header h3 {
  font-size: 36px;
  color: #413e66;
  text-align: center;
  /*font-weight: 700;*/
  position: relative;
  font-family: "Montserrat", sans-serif;
}

.section-header p {
  text-align: center;
  margin: auto;
  font-size: 15px;
  
  color: #535074;
  width: 50%;
}

@media (max-width: 767px) {
  .section-header p {
    width: 100%;
  }
}






/*--------------------------------------------------------------
# Footer
--------------------------------------------------------------*/
#footer {
  padding: 0 0 30px 0;
  font-size: 14px;
  background-color: white;
  color: white;
}

#footer .footer-top {
  padding: 60px 0 30px 0;
  background-color: black;
}

#footer .footer-top .footer-info {
  margin-bottom: 30px;
}

#footer .footer-top .footer-info h3 {
  font-size: 15px;
  margin: 0 0 20px 0;
  padding: 2px 0 2px 0;
  line-height: 1;
  font-family: "Montserrat", sans-serif;
  color: #000000;
  font-weight: 200;
  letter-spacing: 3px;
  text-transform: uppercase;
}

#footer .footer-top .footer-info p {
  font-size: 5px;
  line-height: 24px;
  margin-bottom: 0;
  font-family: "Montserrat", sans-serif;
  color: #535074;
}




@media (max-width: 574px) {
  #footer .footer-top .social-links a {
    margin-bottom: 25px;
  }
}



#footer .footer-top .footer-links {
  margin-bottom: 30px;
  color: white;
}
#footer .footer-top .footer-links h3 {
  font-size: 15px;
  line-height: 1;
  font-weight: 500;
  
  text-transform: uppercase;
}

#footer .footer-top .footer-links p {
  font-size: 13px;
  
  font-weight: 500;
  
  
}

#footer .footer-top .footer-links ul {
  list-style: none;
  padding: 0;
  margin: 0;
  color: white;
}

#footer .footer-top .footer-links ul li {
  padding: 8px 0;
}

#footer .footer-top .footer-links ul li:first-child {
  padding-top: 0;
}

#footer .footer-top .footer-links ul a {
  color: white;
}

#footer .footer-top .footer-links ul a:hover {
  color: white;
}



@-webkit-keyframes animate-loading {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes animate-loading {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

#footer .copyright {
  text-align: center;
  
  color: #000000;
  font-size: 15px;
}





</style>
<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-none d-lg-flex align-items-end fixed-top topbar-transparent">
    <div class="container d-flex justify-content-end">
      <div>
        <a href="Employee_login.php" style="color: black;text-decoration: bold;"> Login</a>  |
        <a href="Employee_register.php" style="color: black;text-decoration: bold;">Register</a>
      </div>
      
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.html"></a></h1>
      

      <nav class="main-nav d-none d-lg-block">
        <ul>
          <li class="#"><a href="index.php"> Home</a></li>        
          <li><a href="admin.php">Admin Login</a></li>
        </ul>
      </nav><!-- .main-nav-->

    </div>


  </header><!-- End Header -->

<main id="main">

   <section id="banner">
    <img class='img-fluid' style="padding-top: 100px; " src="images/Banking-Course-after-12th-Commerce.jpg">

  </section>
<!-- ======= search ======= -->
<section id="search" class="search">

<div class="" >
  <div class="row" style="background-color: blue;"> 
    <div class="container">     
      <div class="search-content">
              
          <h2 align="center">Search Bank Branch </h2> 

        <div class="row" style=" margin-bottom: 30px;">
          
          <div class=" col-md-12">

            <form action="search.php " method="POST">
              <div class="form-row">
                <div class="form-group col-md-5">
                  <input type="text" class="form-control" id="emp_id" placeholder="ID" >
                </div>
                
                <div class="form-group col-md-1">
                  <button type="submit" style="color: white;background-color: black;font-size: 20px;width: 100%"><i class="fa fa-search"></i></button>
                </div>
              </div>


            </form>

           </div>
        </div>                  
      </div>         
    </div>
   </div>
</div>

</section>

</body>



  <!-- ======= Footer ======= -->
  <footer id="footer" >
    <div class="footer-top" >
      <div class="container">

        <div class="row" >

              <div class="col-sm-6">
                <div class="footer-links">
                  <h3>ABC Bank </h3>
                  
                  <p>
                   ABC Bank is....
                  </p>
                  
                </div>
              </div>


          <div class="col-lg-6">

            <div class="row">

              <div class="col-sm-4">
                
              </div>

              <div class="col-sm-8">
                <div class="footer-links">
                  <a href="#" style="font-size: 20px;color:white;background-color: black;"></i>081 2525255</a>
               
                  
                  <h3 style="color: yellow;font-size: 20px;margin-bottom:10px;">CALL NOW FOR MORE DETAILS</h3>
                 
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>

    
      
        <div class="footer-copyright text-center py-3" style="font-size: 15px; color: white; background-color: #330000;">© 2020 ABC Bank All rights resetved 
      </div>
     
    
  </footer>
  <!-- End  Footer -->

 

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  
</body>

</html>