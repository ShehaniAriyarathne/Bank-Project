<?php
include 'functions/dbconnection.php';

if (isset($_POST['submit'])) {  $ins="insert into `bank_branch` (`branch_id`,`branch_name`,`branch_address`)
values('','$_POST[name]','$_POST[address]')";
$insq=mysqli_query($conn,$ins);
} 


?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Branch</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="assets/vendor/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

 
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Add Branch</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
								<div class="border p-1 rounded">
									<form action="" method="post">
										<div class="mb-3">
										<label class="form-label">Bank Name</label>
										<input class="form-control mb-3" name="name" type="text" placeholder="Enter Bank" aria-label="default input example">
									</div>
									<div class="mb-3">
										<label class="form-label">Address</label>
										<input class="form-control mb-3" name="address"type="text" placeholder="Enter Address" aria-label="default input example">
									</div>
									 <div class="row">
										
										<div class="col-sm-18">
											<button type="submit" name="submit" class="btn btn-info px-5">Add</button>
											<button type="reset"  class="btn btn-success px-5">Reset</button>
										</div>
									</div>
									</form>
									</div>
									</div>

                <?php
				include_once "list.php";
				?>
</body>
<script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</html>