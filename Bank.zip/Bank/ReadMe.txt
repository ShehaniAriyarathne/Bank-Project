database name = bank
database user name = root
database password = 


====================================================================

Admin login user name = admin
Admin login password = password